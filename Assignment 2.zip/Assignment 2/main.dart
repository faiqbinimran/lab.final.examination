import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

// ---------------- MAIN APP ----------------
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: FitnessHomePage(),
    );
  }
}

// ---------------- STATELESS WIDGET ----------------
class ExerciseCard extends StatelessWidget {
  final String exerciseName;
  final String calories;
  final IconData icon;

  const ExerciseCard({
    Key? key,
    required this.exerciseName,
    required this.calories,
    required this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      elevation: 5,
      child: ListTile(
        leading: Icon(icon, color: Colors.blue, size: 35),
        title: Text(
          exerciseName,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(calories),
      ),
    );
  }
}

// ---------------- STATEFUL WIDGET ----------------
class FitnessHomePage extends StatefulWidget {
  @override
  _FitnessHomePageState createState() => _FitnessHomePageState();
}

class _FitnessHomePageState extends State<FitnessHomePage> {
  int waterGlasses = 0;

  void addWater() {
    setState(() {
      waterGlasses++;
    });
  }

  void resetWater() {
    setState(() {
      waterGlasses = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fitness Tracker"),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: Column(
          children: [

            // Stateless Widget Calls
            ExerciseCard(
              exerciseName: "Cycling",
              calories: "Burns 300 Calories",
              icon: Icons.pedal_bike,
            ),

            ExerciseCard(
              exerciseName: "Running",
              calories: "Burns 250 Calories",
              icon: Icons.directions_run,
            ),

            ExerciseCard(
              exerciseName: "Yoga",
              calories: "Burns 150 Calories",
              icon: Icons.self_improvement,
            ),

            SizedBox(height: 30),

            Text(
              "Water Intake",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: 20),

            Text(
              "$waterGlasses Glasses",
              style: TextStyle(
                fontSize: 30,
                color: Colors.blue,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: addWater,
                  child: Text("Add Water"),
                ),

                ElevatedButton(
                  onPressed: resetWater,
                  child: Text("Reset"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}